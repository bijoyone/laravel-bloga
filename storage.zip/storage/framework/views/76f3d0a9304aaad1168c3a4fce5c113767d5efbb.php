<!DOCTYPE html>
<html lang="en">

<head>

<?php echo $__env->make('clean_blog.partials.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</head>

<body>

<!-- Navigation -->
<?php echo $__env->make('clean_blog.partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Navigation -->


<?php echo $__env->yieldContent('content'); ?>

<hr>

<!-- Footer -->
<?php echo $__env->make('clean_blog.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!-- Footer -->


<!--scripts-->
<?php echo $__env->make('clean_blog.partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<!--scripts-->





</body>

</html>
