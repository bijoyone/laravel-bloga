
<!-- jQuery -->
<script src=" <?php echo e(asset('clean_blog/vendor/jquery/jquery.min.js')); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src=" <?php echo e(asset('clean_blog/vendor/bootstrap/js/bootstrap.min.js')); ?>"></script>

<!-- Contact Form JavaScript -->

<script src=" <?php echo e(asset('clean_blog/js/jqBootstrapValidation.js')); ?>"></script>
<script src=" <?php echo e(asset('clean_blog/js/contact_me.js')); ?>"></script>

<!-- Theme JavaScript -->
<script src=" <?php echo e(asset('clean_blog/js/clean-blog.min.js')); ?>"></script>


<!--custom script-->
<?php echo $__env->yieldPushContent('scripts'); ?>